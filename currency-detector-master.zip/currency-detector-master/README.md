# Currency Detector

Indian paper currency detection using Image Processing, opencv3 and python3.


 -  To run do python3 detect.py

 - To set a different image modify the testing_image in detect.py

 - The failed parts are in try.py

## TODO:
- Figure out four point transform
- Figure out testing data warping
- Use webcam as input
- Figure out how to use contours
- Currently detects inner rect -> detect outermost rectangle
- Try using video stream from android phone
